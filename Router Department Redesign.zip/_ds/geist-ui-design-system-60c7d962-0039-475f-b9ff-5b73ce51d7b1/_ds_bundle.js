/* @ds-bundle: {"format":4,"namespace":"GeistUIDesignSystem_60c7d9","components":[{"name":"Avatar","sourcePath":"components/display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"Code","sourcePath":"components/display/Code.jsx"},{"name":"Dot","sourcePath":"components/display/Dot.jsx"},{"name":"Keyboard","sourcePath":"components/display/Keyboard.jsx"},{"name":"Snippet","sourcePath":"components/display/Snippet.jsx"},{"name":"Table","sourcePath":"components/display/Table.jsx"},{"name":"Tag","sourcePath":"components/display/Tag.jsx"},{"name":"Text","sourcePath":"components/display/Text.jsx"},{"name":"User","sourcePath":"components/display/User.jsx"},{"name":"Loading","sourcePath":"components/feedback/Loading.jsx"},{"name":"Note","sourcePath":"components/feedback/Note.jsx"},{"name":"Progress","sourcePath":"components/feedback/Progress.jsx"},{"name":"Spinner","sourcePath":"components/feedback/Spinner.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Slider","sourcePath":"components/forms/Slider.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Toggle","sourcePath":"components/forms/Toggle.jsx"},{"name":"Breadcrumbs","sourcePath":"components/navigation/Breadcrumbs.jsx"},{"name":"Link","sourcePath":"components/navigation/Link.jsx"},{"name":"Pagination","sourcePath":"components/navigation/Pagination.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Collapse","sourcePath":"components/overlay/Collapse.jsx"},{"name":"Modal","sourcePath":"components/overlay/Modal.jsx"},{"name":"Tooltip","sourcePath":"components/overlay/Tooltip.jsx"}],"sourceHashes":{"components/display/Avatar.jsx":"e8dac1220a55","components/display/Badge.jsx":"dbf85206c4f2","components/display/Card.jsx":"0a1d9e8bf8e7","components/display/Code.jsx":"ba154dfa3fc8","components/display/Dot.jsx":"cab2d14456b6","components/display/Keyboard.jsx":"5e25c225fbd5","components/display/Snippet.jsx":"e457f2397914","components/display/Table.jsx":"c4d9bb612084","components/display/Tag.jsx":"3141f5a4340e","components/display/Text.jsx":"aa9a47d15269","components/display/User.jsx":"267769053acd","components/feedback/Loading.jsx":"9bb58261a11d","components/feedback/Note.jsx":"81035e365806","components/feedback/Progress.jsx":"286df67aadf1","components/feedback/Spinner.jsx":"87d7f3b89288","components/forms/Button.jsx":"c57d5129d14c","components/forms/Checkbox.jsx":"43fd7cf910f6","components/forms/Input.jsx":"36dda0001941","components/forms/Radio.jsx":"c7821c3aad90","components/forms/Select.jsx":"46b39bf11953","components/forms/Slider.jsx":"68345586b063","components/forms/Textarea.jsx":"23b2aa6ff0e3","components/forms/Toggle.jsx":"bb7f600aadd4","components/navigation/Breadcrumbs.jsx":"1cbad2d72bdb","components/navigation/Link.jsx":"3c367323a876","components/navigation/Pagination.jsx":"d46b0cf6ca1e","components/navigation/Tabs.jsx":"9c64e9d54de7","components/overlay/Collapse.jsx":"3c71c8c65022","components/overlay/Modal.jsx":"28d841fd05bd","components/overlay/Tooltip.jsx":"d5d10e1c2425","ui_kits/geist-docs/Docs.jsx":"ed7e40b8c8a0","ui_kits/geist-docs/Home.jsx":"6df4f7ca5ba4","ui_kits/geist-docs/Sidebar.jsx":"c355c9742d68","ui_kits/geist-docs/TopNav.jsx":"19e67056bfb8"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.GeistUIDesignSystem_60c7d9 = window.GeistUIDesignSystem_60c7d9 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/display/Avatar.jsx
try { (() => {
function Avatar({
  src,
  text = '',
  isSquare = false,
  size = 28,
  stacked = false,
  style
}) {
  const radius = isSquare ? 'var(--geist-radius)' : '50%';
  const safe = text.length <= 4 ? text : text.slice(0, 3);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      position: 'relative',
      overflow: 'hidden',
      border: '1px solid var(--geist-accents-2)',
      borderRadius: radius,
      width: size,
      height: size,
      background: '#fff',
      verticalAlign: 'top',
      marginLeft: stacked ? -10 : 0,
      boxSizing: 'border-box',
      ...style
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    alt: "avatar",
    src: src,
    draggable: false,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block',
      borderRadius: radius
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: '50%',
      top: '50%',
      transform: 'translate(-50%,-50%) scale(0.65)',
      fontSize: size * 0.6,
      fontFamily: 'var(--geist-font-sans)',
      whiteSpace: 'nowrap',
      color: 'var(--geist-accents-5)'
    }
  }, safe));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/display/Badge.jsx
try { (() => {
function Badge({
  type = 'default',
  dot = false,
  children,
  style
}) {
  const bg = {
    default: 'var(--geist-foreground)',
    success: 'var(--geist-success)',
    warning: 'var(--geist-warning)',
    error: 'var(--geist-error)',
    secondary: 'var(--geist-secondary)'
  }[type] || 'var(--geist-foreground)';
  const color = type === 'default' ? 'var(--geist-background)' : '#fff';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      background: bg,
      color,
      borderRadius: dot ? '50%' : 16,
      fontSize: 14,
      lineHeight: 1,
      fontVariant: 'tabular-nums',
      padding: dot ? 4 : '4px 7px',
      fontFamily: 'var(--geist-font-sans)',
      verticalAlign: 'middle',
      ...style
    }
  }, !dot && children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
const {
  useState
} = React;
function Card({
  type = 'default',
  shadow = false,
  hoverable = false,
  width,
  children,
  footer,
  style
}) {
  const [hover, setHover] = useState(false);
  const typeBorder = {
    default: 'var(--geist-border)',
    success: 'var(--geist-success)',
    warning: 'var(--geist-warning)',
    error: 'var(--geist-error)',
    secondary: 'var(--geist-accents-2)'
  }[type] || 'var(--geist-border)';
  const box = shadow ? hover ? 'var(--geist-shadow-medium)' : 'var(--geist-shadow-small)' : hoverable && hover ? 'var(--geist-shadow-small)' : 'none';
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: '#fff',
      border: `1px solid ${typeBorder}`,
      borderRadius: 'var(--geist-radius)',
      boxShadow: box,
      transition: 'box-shadow .2s ease',
      width,
      boxSizing: 'border-box',
      fontFamily: 'var(--geist-font-sans)',
      color: 'var(--geist-foreground)',
      overflow: 'hidden',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      fontSize: 14,
      lineHeight: 1.6
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--geist-border)',
      padding: '12px 16px',
      background: 'var(--geist-accents-1)',
      fontSize: 13,
      color: 'var(--geist-accents-5)'
    }
  }, footer));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/Code.jsx
try { (() => {
function Code({
  block = false,
  name,
  children,
  style
}) {
  if (!block) {
    return /*#__PURE__*/React.createElement("code", {
      style: {
        fontFamily: 'var(--geist-font-mono)',
        fontSize: '0.9em',
        color: 'var(--geist-code)',
        background: 'rgba(250,250,250,.75)',
        border: '1px solid var(--geist-accents-1)',
        borderRadius: 'var(--geist-radius)',
        padding: '2px 6px',
        ...style
      }
    }, children);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '100%',
      border: '1px solid var(--geist-accents-1)',
      borderRadius: 'var(--geist-radius)',
      background: 'rgba(250,250,250,.75)',
      fontSize: 14,
      fontFamily: 'var(--geist-font-mono)',
      ...style
    }
  }, name && /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--geist-accents-2)',
      background: 'var(--geist-accents-2)',
      color: 'var(--geist-accents-5)',
      fontSize: 13,
      padding: '5px 8px',
      borderTopLeftRadius: 5,
      borderBottomRightRadius: 6
    }
  }, name)), /*#__PURE__*/React.createElement("pre", {
    style: {
      margin: 0,
      padding: '16px',
      lineHeight: 1.5,
      color: 'var(--geist-foreground)',
      fontFamily: 'inherit',
      overflowX: 'auto'
    }
  }, children));
}
Object.assign(__ds_scope, { Code });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Code.jsx", error: String((e && e.message) || e) }); }

// components/display/Dot.jsx
try { (() => {
function Dot({
  type = 'default',
  children,
  style
}) {
  const color = {
    default: 'var(--geist-accents-2)',
    success: 'var(--geist-success)',
    warning: 'var(--geist-warning)',
    error: 'var(--geist-error)'
  }[type] || 'var(--geist-accents-2)';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--geist-font-sans)',
      fontSize: 14,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: color,
      flexShrink: 0
    }
  }), children != null && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 8,
      lineHeight: 1
    }
  }, children));
}
Object.assign(__ds_scope, { Dot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Dot.jsx", error: String((e && e.message) || e) }); }

// components/display/Keyboard.jsx
try { (() => {
function Keyboard({
  command,
  shift,
  option,
  ctrl,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("kbd", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      minWidth: 32,
      minHeight: 32,
      justifyContent: 'center',
      lineHeight: 2,
      textAlign: 'center',
      color: 'var(--geist-accents-5)',
      background: 'var(--geist-accents-1)',
      border: '1px solid var(--geist-accents-2)',
      borderRadius: 'var(--geist-radius)',
      fontFamily: 'var(--geist-font-sans)',
      fontSize: 14,
      padding: '0 6px',
      ...style
    }
  }, command && /*#__PURE__*/React.createElement("span", null, "\u2318"), shift && /*#__PURE__*/React.createElement("span", null, "\u21E7"), option && /*#__PURE__*/React.createElement("span", null, "\u2325"), ctrl && /*#__PURE__*/React.createElement("span", null, "\u2303"), children != null && /*#__PURE__*/React.createElement("span", null, children));
}
Object.assign(__ds_scope, { Keyboard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Keyboard.jsx", error: String((e && e.message) || e) }); }

// components/display/Snippet.jsx
try { (() => {
const {
  useState
} = React;
function Snippet({
  text = '',
  symbol = '$',
  filled = false,
  width,
  style
}) {
  const [copied, setCopied] = useState(false);
  const lines = Array.isArray(text) ? text : [text];
  const sym = symbol.trim() ? symbol.trim() + ' ' : '';
  const copy = () => {
    const str = lines.join('\n');
    if (navigator.clipboard) navigator.clipboard.writeText(str);
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: '100%',
      width,
      background: filled ? 'var(--geist-accents-1)' : '#fff',
      color: 'var(--geist-foreground)',
      border: '1px solid var(--geist-border)',
      borderRadius: 'var(--geist-radius)',
      fontFamily: 'var(--geist-font-mono)',
      fontSize: 13,
      padding: '11px 44px 11px 11px',
      boxSizing: 'border-box',
      ...style
    }
  }, lines.map((t, i) => /*#__PURE__*/React.createElement("pre", {
    key: i,
    style: {
      margin: 0,
      fontFamily: 'inherit',
      fontSize: 'inherit'
    }
  }, sym, t)), /*#__PURE__*/React.createElement("div", {
    onClick: copy,
    title: "Copy",
    style: {
      position: 'absolute',
      right: 0,
      top: 0,
      bottom: 0,
      width: 40,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      opacity: 0.65,
      transition: 'opacity .15s ease',
      borderRadius: 'var(--geist-radius)'
    },
    onMouseEnter: e => e.currentTarget.style.opacity = 1,
    onMouseLeave: e => e.currentTarget.style.opacity = 0.65
  }, copied ? /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--geist-success)",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  })) : /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "9",
    y: "9",
    width: "13",
    height: "13",
    rx: "2",
    ry: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"
  }))));
}
Object.assign(__ds_scope, { Snippet });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Snippet.jsx", error: String((e && e.message) || e) }); }

// components/display/Table.jsx
try { (() => {
function Table({
  columns = [],
  data = [],
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      fontFamily: 'var(--geist-font-sans)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.prop,
    style: {
      textAlign: 'left',
      fontWeight: 600,
      color: 'var(--geist-accents-6)',
      background: 'var(--geist-accents-1)',
      padding: '10px 12px',
      borderBottom: '1px solid var(--geist-border)',
      whiteSpace: 'nowrap'
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, data.map((row, ri) => /*#__PURE__*/React.createElement("tr", {
    key: ri
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.prop,
    style: {
      padding: '12px',
      color: 'var(--geist-foreground)',
      borderBottom: '1px solid var(--geist-border)'
    }
  }, c.render ? c.render(row[c.prop], row) : row[c.prop])))))));
}
Object.assign(__ds_scope, { Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Table.jsx", error: String((e && e.message) || e) }); }

// components/display/Tag.jsx
try { (() => {
function Tag({
  type = 'default',
  invert = false,
  children,
  style
}) {
  const map = {
    default: {
      color: 'var(--geist-foreground)',
      bg: '#fff'
    },
    success: {
      color: 'var(--geist-success)',
      bg: '#fff'
    },
    warning: {
      color: 'var(--geist-warning)',
      bg: '#fff'
    },
    error: {
      color: 'var(--geist-error)',
      bg: '#fff'
    },
    secondary: {
      color: 'var(--geist-secondary)',
      bg: '#fff'
    },
    lite: {
      color: 'var(--geist-foreground)',
      bg: 'var(--geist-accents-2)',
      noBorder: true
    },
    dark: {
      color: '#fff',
      bg: '#000'
    }
  };
  let c = map[type] || map.default;
  let color = c.color,
    bg = c.bg,
    border = c.noBorder ? 'transparent' : c.color;
  if (invert) {
    const t = color;
    color = bg === '#fff' ? '#fff' : bg;
    bg = t;
    border = 'transparent';
  }
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      border: `1px solid ${border}`,
      background: bg,
      color,
      borderRadius: 5,
      fontSize: 14,
      lineHeight: 1,
      padding: '6px 6px',
      boxSizing: 'border-box',
      fontFamily: 'var(--geist-font-sans)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/display/Text.jsx
try { (() => {
const TYPE_COLOR = {
  default: 'var(--geist-foreground)',
  secondary: 'var(--geist-secondary)',
  success: 'var(--geist-success)',
  warning: 'var(--geist-warning)',
  error: 'var(--geist-error)'
};
const TAG_STYLE = {
  h1: {
    fontSize: 40,
    fontWeight: 700,
    lineHeight: 1.2,
    margin: '0 0 .5em'
  },
  h2: {
    fontSize: 32,
    fontWeight: 700,
    lineHeight: 1.2,
    margin: '0 0 .5em'
  },
  h3: {
    fontSize: 24,
    fontWeight: 600,
    lineHeight: 1.3,
    margin: '0 0 .5em'
  },
  h4: {
    fontSize: 20,
    fontWeight: 600,
    lineHeight: 1.3,
    margin: '0 0 .5em'
  },
  h5: {
    fontSize: 16,
    fontWeight: 600,
    lineHeight: 1.4,
    margin: '0 0 .5em'
  },
  h6: {
    fontSize: 14,
    fontWeight: 600,
    lineHeight: 1.4,
    margin: '0 0 .5em'
  },
  p: {
    fontSize: 16,
    fontWeight: 400,
    lineHeight: 1.6,
    margin: '0 0 1em'
  },
  small: {
    fontSize: 13,
    lineHeight: 1.5
  },
  blockquote: {
    fontSize: 15,
    lineHeight: 1.6,
    margin: 0,
    padding: '12px 16px',
    background: 'var(--geist-accents-1)',
    border: '1px solid var(--geist-border)',
    borderRadius: 'var(--geist-radius)'
  }
};
function Text({
  h1,
  h2,
  h3,
  h4,
  h5,
  h6,
  p,
  small,
  b,
  i,
  del,
  blockquote,
  span,
  type = 'default',
  children,
  style
}) {
  const tag = h1 ? 'h1' : h2 ? 'h2' : h3 ? 'h3' : h4 ? 'h4' : h5 ? 'h5' : h6 ? 'h6' : blockquote ? 'blockquote' : small ? 'small' : span ? 'span' : b ? 'b' : i ? 'i' : del ? 'del' : 'p';
  const base = TAG_STYLE[tag] || {};
  const Tag = tag;
  return /*#__PURE__*/React.createElement(Tag, {
    style: {
      fontFamily: 'var(--geist-font-sans)',
      color: TYPE_COLOR[type],
      ...base,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Text });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Text.jsx", error: String((e && e.message) || e) }); }

// components/display/User.jsx
try { (() => {
function User({
  src,
  name,
  text,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      fontFamily: 'var(--geist-font-sans)',
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    src: src,
    text: text,
    size: 32
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1.3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: 'var(--geist-foreground)'
    }
  }, name), children != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--geist-accents-5)'
    }
  }, children)));
}
Object.assign(__ds_scope, { User });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/User.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Loading.jsx
try { (() => {
function Loading({
  type = 'default',
  color,
  children,
  style
}) {
  const bg = color || {
    default: 'var(--geist-accents-6)',
    secondary: 'var(--geist-secondary)',
    success: 'var(--geist-success)',
    warning: 'var(--geist-warning)',
    error: 'var(--geist-error)'
  }[type];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--geist-font-sans)',
      fontSize: 16,
      ...style
    }
  }, children != null && /*#__PURE__*/React.createElement("span", {
    style: {
      marginRight: '.5em',
      color: 'var(--geist-accents-5)',
      fontSize: 14
    }
  }, children), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center'
    }
  }, [0, 0.2, 0.4].map((d, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: '.25em',
      height: '.25em',
      borderRadius: '50%',
      background: bg,
      margin: '0 .125em',
      display: 'inline-block',
      animation: `geist-loading-blink 1.4s ${d}s infinite both`
    }
  }))), /*#__PURE__*/React.createElement("style", null, `@keyframes geist-loading-blink{0%{opacity:.2}20%{opacity:1}100%{opacity:.2}}`));
}
Object.assign(__ds_scope, { Loading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Loading.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Note.jsx
try { (() => {
function Note({
  type = 'default',
  label = 'note',
  filled = false,
  children,
  style
}) {
  const status = {
    secondary: 'var(--geist-secondary)',
    success: 'var(--geist-success)',
    warning: 'var(--geist-warning)',
    error: 'var(--geist-error)'
  }[type];
  let color, border, bg;
  if (!filled) {
    color = status || 'var(--geist-foreground)';
    border = status || 'var(--geist-border)';
    bg = '#fff';
  } else {
    color = status ? '#fff' : 'var(--geist-background)';
    border = status || 'var(--geist-foreground)';
    bg = status || 'var(--geist-foreground)';
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.8,
      border: `1px solid ${border}`,
      color,
      background: bg,
      borderRadius: 'var(--geist-radius)',
      fontSize: 14,
      padding: '11px 21px',
      fontFamily: 'var(--geist-font-sans)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      textTransform: 'uppercase',
      paddingRight: '.38em'
    }
  }, /*#__PURE__*/React.createElement("b", null, label, ":")), children);
}
Object.assign(__ds_scope, { Note });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Note.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Progress.jsx
try { (() => {
function Progress({
  value = 0,
  max = 100,
  type = 'default',
  colors,
  style
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  let color = {
    default: 'var(--geist-foreground)',
    success: 'var(--geist-success)',
    secondary: 'var(--geist-secondary)',
    warning: 'var(--geist-warning)',
    error: 'var(--geist-error)'
  }[type] || 'var(--geist-foreground)';
  if (colors) {
    const key = Object.keys(colors).map(Number).sort((a, b) => a - b).find(k => pct <= k);
    if (key !== undefined) color = colors[key];
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: 10,
      background: 'var(--geist-accents-2)',
      borderRadius: 'var(--geist-radius)',
      overflow: 'hidden',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      height: '100%',
      width: `${pct}%`,
      background: color,
      borderRadius: 'var(--geist-radius)',
      transition: 'width .1s ease-in'
    }
  }));
}
Object.assign(__ds_scope, { Progress });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Progress.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Spinner.jsx
try { (() => {
function Spinner({
  size = 20,
  color = 'var(--geist-foreground)',
  style
}) {
  const bars = [...Array(12)].map((_, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      position: 'absolute',
      top: '-3.9%',
      left: '-10%',
      width: '24%',
      height: '8%',
      background: color,
      borderRadius: 'var(--geist-radius)',
      transform: `rotate(${i * 30}deg) translate(146%)`,
      animation: `geist-spin 1.2s linear ${-1.2 + i * 0.1}s infinite normal none running`
    }
  }));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-block',
      width: size,
      height: size,
      position: 'relative',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      position: 'relative',
      left: '50%',
      top: '50%'
    }
  }, bars), /*#__PURE__*/React.createElement("style", null, `@keyframes geist-spin{0%{opacity:1}100%{opacity:.15}}`));
}
Object.assign(__ds_scope, { Spinner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Spinner.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
const HEIGHTS = {
  mini: 32,
  small: 32,
  medium: 40,
  large: 48
};
const FONTS = {
  mini: 12,
  small: 14,
  medium: 14,
  large: 16
};
function resolveColors(type, ghost, disabled) {
  if (disabled) return {
    bg: 'var(--geist-accents-1)',
    border: 'var(--geist-accents-2)',
    color: '#ccc'
  };
  const base = type.replace('-light', '');
  if (ghost) {
    const g = {
      secondary: {
        bg: '#fff',
        border: '#000',
        color: '#000'
      },
      success: {
        bg: '#fff',
        border: 'var(--geist-success)',
        color: 'var(--geist-success)'
      },
      warning: {
        bg: '#fff',
        border: 'var(--geist-warning)',
        color: 'var(--geist-warning)'
      },
      error: {
        bg: '#fff',
        border: 'var(--geist-error)',
        color: 'var(--geist-error)'
      }
    };
    return g[base] || {
      bg: '#fff',
      border: 'var(--geist-border)',
      color: 'var(--geist-accents-5)'
    };
  }
  const c = {
    default: {
      bg: '#fff',
      border: 'var(--geist-border)',
      color: 'var(--geist-accents-5)'
    },
    secondary: {
      bg: '#000',
      border: '#000',
      color: '#fff'
    },
    success: {
      bg: 'var(--geist-success)',
      border: 'var(--geist-success)',
      color: '#fff'
    },
    warning: {
      bg: 'var(--geist-warning)',
      border: 'var(--geist-warning)',
      color: '#fff'
    },
    error: {
      bg: 'var(--geist-error)',
      border: 'var(--geist-error)',
      color: '#fff'
    },
    abort: {
      bg: 'transparent',
      border: 'transparent',
      color: 'var(--geist-accents-5)'
    }
  };
  return c[base] || c.default;
}
function resolveHover(type, ghost, disabled, shadow) {
  if (disabled || shadow) return null;
  const base = type.replace('-light', '');
  if (ghost) {
    const g = {
      secondary: {
        bg: '#000',
        border: '#000',
        color: '#fff'
      },
      success: {
        bg: 'var(--geist-success)',
        border: 'var(--geist-success)',
        color: '#fff'
      },
      warning: {
        bg: 'var(--geist-warning)',
        border: 'var(--geist-warning)',
        color: '#fff'
      },
      error: {
        bg: 'var(--geist-error)',
        border: 'var(--geist-error)',
        color: '#fff'
      }
    };
    return g[base] || null;
  }
  const c = {
    default: {
      bg: '#fff',
      border: '#000',
      color: '#000'
    },
    secondary: {
      bg: '#fff',
      border: '#000',
      color: '#000'
    },
    success: {
      bg: '#fff',
      border: 'var(--geist-success)',
      color: 'var(--geist-success)'
    },
    warning: {
      bg: '#fff',
      border: 'var(--geist-warning)',
      color: 'var(--geist-warning)'
    },
    error: {
      bg: '#fff',
      border: 'var(--geist-error)',
      color: 'var(--geist-error)'
    },
    abort: {
      bg: 'transparent',
      border: 'transparent',
      color: 'var(--geist-accents-3)'
    }
  };
  return c[base] || c.default;
}
function Button({
  type = 'default',
  size = 'medium',
  ghost = false,
  shadow = false,
  loading = false,
  disabled = false,
  auto = false,
  icon,
  iconRight,
  children,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const rest0 = resolveColors(type, ghost, disabled);
  const hov = resolveHover(type, ghost, disabled, shadow);
  const active = hover && hov ? hov : rest0;
  const h = HEIGHTS[size] || 40;
  const pad = auto ? 18 : 22;
  const s = {
    boxSizing: 'border-box',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: h,
    minWidth: auto ? 'min-content' : 168,
    padding: `0 ${pad}px`,
    borderRadius: 'var(--geist-radius)',
    border: `1px solid ${active.border}`,
    background: active.bg,
    color: loading ? 'transparent' : active.color,
    fontFamily: 'var(--geist-font-sans)',
    fontSize: FONTS[size] || 14,
    fontWeight: 400,
    lineHeight: 1,
    textTransform: 'capitalize',
    whiteSpace: 'nowrap',
    userSelect: 'none',
    cursor: disabled ? 'not-allowed' : loading ? 'default' : 'pointer',
    outline: 'none',
    position: 'relative',
    boxShadow: shadow ? hover ? 'var(--geist-shadow-medium)' : 'var(--geist-shadow-small)' : 'none',
    transform: shadow && hover ? 'translate3d(0,-1px,0)' : 'none',
    transition: 'background-color .2s ease, box-shadow .2s ease, border .2s ease, color .2s ease, transform .2s ease',
    ...style
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    style: s,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: disabled || loading ? undefined : onClick
  }, rest), loading && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 4
    }
  }, [0, 0.2, 0.4].map((d, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: 4,
      height: 4,
      borderRadius: '50%',
      background: rest0.color,
      animation: `geist-blink 1.4s ${d}s infinite both`
    }
  })), /*#__PURE__*/React.createElement("style", null, `@keyframes geist-blink{0%{opacity:.2}20%{opacity:1}100%{opacity:.2}}`)), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center'
    }
  }, icon), children != null && /*#__PURE__*/React.createElement("span", null, children), iconRight && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center'
    }
  }, iconRight));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
const {
  useState
} = React;
function Checkbox({
  checked,
  initialChecked = false,
  disabled = false,
  type = 'default',
  children,
  onChange,
  style
}) {
  const [self, setSelf] = useState(initialChecked);
  const controlled = checked !== undefined;
  const on = controlled ? checked : self;
  const fill = {
    default: '#000',
    success: 'var(--geist-success)',
    warning: 'var(--geist-warning)',
    error: 'var(--geist-error)'
  }[type] || '#000';
  const toggle = () => {
    if (disabled) return;
    if (!controlled) setSelf(!on);
    onChange && onChange({
      target: {
        checked: !on
      }
    });
  };
  return /*#__PURE__*/React.createElement("label", {
    onClick: toggle,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.75 : 1,
      fontFamily: 'var(--geist-font-sans)',
      userSelect: 'none',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 15,
      height: 15,
      borderRadius: 4,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: `1px solid ${on ? fill : 'var(--geist-accents-3)'}`,
      background: on ? fill : '#fff',
      transition: 'all .15s ease',
      flexShrink: 0
    }
  }, on && /*#__PURE__*/React.createElement("svg", {
    width: "10",
    height: "10",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#fff",
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }))), children != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--geist-foreground)'
    }
  }, children));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
const TYPE_BORDER = {
  default: 'var(--geist-border)',
  success: 'var(--geist-success)',
  warning: 'var(--geist-warning)',
  error: 'var(--geist-error)'
};
function Input({
  label,
  labelRight,
  icon,
  iconRight,
  clearable = false,
  type = 'default',
  width = '208px',
  disabled = false,
  value,
  defaultValue,
  placeholder,
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = useState(false);
  const [val, setVal] = useState(defaultValue || '');
  const controlled = value !== undefined;
  const cur = controlled ? value : val;
  const border = TYPE_BORDER[type] || 'var(--geist-border)';
  const hoverBorder = type === 'default' ? '#000' : border;
  const labelStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    height: '100%',
    padding: '0 10px',
    background: 'var(--geist-accents-1)',
    border: `1px solid var(--geist-border)`,
    color: 'var(--geist-accents-5)',
    fontSize: 14,
    whiteSpace: 'nowrap',
    fontFamily: 'var(--geist-font-sans)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      flexDirection: 'column',
      width,
      fontFamily: 'var(--geist-font-sans)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      height: 36
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      ...labelStyle,
      borderRight: 'none',
      borderRadius: 'var(--geist-radius) 0 0 var(--geist-radius)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      flex: 1,
      height: '100%',
      border: `1px solid ${disabled ? 'var(--geist-accents-2)' : focus ? hoverBorder : border}`,
      background: disabled ? 'var(--geist-accents-1)' : '#fff',
      borderRadius: label ? '0 var(--geist-radius) var(--geist-radius) 0' : labelRight ? 'var(--geist-radius) 0 0 var(--geist-radius)' : 'var(--geist-radius)',
      transition: 'border .2s ease',
      overflow: 'hidden'
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      paddingLeft: 8,
      color: 'var(--geist-accents-4)'
    }
  }, icon), /*#__PURE__*/React.createElement("input", _extends({
    value: cur,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    onChange: e => {
      if (!controlled) setVal(e.target.value);
      onChange && onChange(e);
    },
    style: {
      margin: '4px 10px',
      padding: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontSize: 14,
      width: '100%',
      minWidth: 0,
      color: 'var(--geist-foreground)',
      fontFamily: 'var(--geist-font-sans)',
      cursor: disabled ? 'not-allowed' : 'text'
    }
  }, rest)), clearable && cur && !disabled && /*#__PURE__*/React.createElement("span", {
    onClick: () => {
      if (!controlled) setVal('');
      onChange && onChange({
        target: {
          value: ''
        }
      });
    },
    style: {
      display: 'inline-flex',
      paddingRight: 8,
      color: 'var(--geist-accents-4)',
      cursor: 'pointer'
    }
  }, "\u2715"), iconRight && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      paddingRight: 8,
      color: 'var(--geist-accents-4)'
    }
  }, iconRight)), labelRight && /*#__PURE__*/React.createElement("span", {
    style: {
      ...labelStyle,
      borderLeft: 'none',
      borderRadius: '0 var(--geist-radius) var(--geist-radius) 0'
    }
  }, labelRight)));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
const {
  useState
} = React;
function Radio({
  checked,
  value,
  groupValue,
  disabled = false,
  type = 'default',
  children,
  description,
  onChange,
  style
}) {
  const [self, setSelf] = useState(!!checked);
  const inGroup = groupValue !== undefined;
  const on = inGroup ? groupValue === value : checked !== undefined ? checked : self;
  const fill = {
    default: '#000',
    success: 'var(--geist-success)',
    warning: 'var(--geist-warning)',
    error: 'var(--geist-error)'
  }[type] || '#000';
  const click = () => {
    if (disabled) return;
    if (checked === undefined && !inGroup) setSelf(!on);
    onChange && onChange({
      target: {
        checked: !on
      },
      value
    });
  };
  return /*#__PURE__*/React.createElement("label", {
    onClick: click,
    style: {
      display: 'inline-flex',
      flexDirection: 'column',
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontFamily: 'var(--geist-font-sans)',
      userSelect: 'none',
      opacity: disabled ? 0.6 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14,
      height: 14,
      borderRadius: '50%',
      flexShrink: 0,
      border: `1px solid ${on ? fill : 'var(--geist-accents-3)'}`,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'all .2s ease'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: fill,
      transform: on ? 'scale(1)' : 'scale(0)',
      transition: 'transform .2s ease'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--geist-foreground)'
    }
  }, children)), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--geist-accents-5)',
      paddingLeft: 22,
      marginTop: 2,
      fontWeight: 400
    }
  }, description));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
const {
  useState,
  useRef,
  useEffect
} = React;
function Select({
  options = [],
  value,
  defaultValue,
  placeholder = 'Select option',
  disabled = false,
  multiple = false,
  width = '208px',
  onChange,
  style
}) {
  const [open, setOpen] = useState(false);
  const [val, setVal] = useState(defaultValue !== undefined ? defaultValue : multiple ? [] : '');
  const controlled = value !== undefined;
  const cur = controlled ? value : val;
  const ref = useRef(null);
  useEffect(() => {
    const h = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  const pick = v => {
    let next;
    if (multiple) next = Array.isArray(cur) && cur.includes(v) ? cur.filter(x => x !== v) : [...(cur || []), v];else {
      next = v;
      setOpen(false);
    }
    if (!controlled) setVal(next);
    onChange && onChange(next);
  };
  const label = v => (options.find(o => o.value === v) || {}).label || v;
  const isEmpty = multiple ? !cur || cur.length === 0 : !cur;
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: 'relative',
      width,
      fontFamily: 'var(--geist-font-sans)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => !disabled && setOpen(!open),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      minHeight: 36,
      padding: '0 10px',
      border: `1px solid ${disabled ? 'var(--geist-border)' : open ? '#000' : 'var(--geist-border)'}`,
      borderRadius: 'var(--geist-radius)',
      background: disabled ? 'var(--geist-accents-1)' : '#fff',
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontSize: 14,
      transition: 'border .15s ease',
      color: isEmpty ? 'var(--geist-accents-3)' : 'var(--geist-foreground)',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      display: 'flex',
      gap: 4,
      flexWrap: 'wrap'
    }
  }, isEmpty ? placeholder : multiple ? cur.map(v => /*#__PURE__*/React.createElement("span", {
    key: v,
    style: {
      background: 'var(--geist-accents-2)',
      borderRadius: 'var(--geist-radius)',
      padding: '1px 8px',
      fontSize: 13
    }
  }, label(v))) : label(cur)), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--geist-accents-5)',
      transform: open ? 'rotate(180deg)' : 'none',
      transition: 'transform .2s ease',
      fontSize: 11
    }
  }, "\u25BE")), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'calc(100% + 4px)',
      left: 0,
      right: 0,
      zIndex: 20,
      background: '#fff',
      border: '1px solid var(--geist-border)',
      borderRadius: 'var(--geist-radius)',
      boxShadow: 'var(--geist-shadow-small)',
      padding: 4,
      maxHeight: 240,
      overflowY: 'auto'
    }
  }, options.map(o => {
    const sel = multiple ? cur.includes(o.value) : cur === o.value;
    return /*#__PURE__*/React.createElement("div", {
      key: o.value,
      onClick: () => pick(o.value),
      style: {
        padding: '8px 10px',
        borderRadius: 'var(--geist-radius)',
        fontSize: 14,
        cursor: 'pointer',
        background: sel ? 'var(--geist-accents-1)' : 'transparent',
        color: sel ? 'var(--geist-foreground)' : 'var(--geist-accents-6)',
        fontWeight: sel ? 600 : 400
      },
      onMouseEnter: e => {
        if (!sel) e.currentTarget.style.background = 'var(--geist-accents-1)';
      },
      onMouseLeave: e => {
        if (!sel) e.currentTarget.style.background = 'transparent';
      }
    }, o.label);
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Slider.jsx
try { (() => {
const {
  useState,
  useRef
} = React;
function Slider({
  value,
  initialValue = 0,
  min = 0,
  max = 100,
  step = 1,
  disabled = false,
  width = '240px',
  onChange,
  style
}) {
  const [self, setSelf] = useState(initialValue);
  const controlled = value !== undefined;
  const cur = controlled ? value : self;
  const ref = useRef(null);
  const pct = (cur - min) / (max - min) * 100;
  const setFromEvent = e => {
    if (disabled || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    let r = (e.clientX - rect.left) / rect.width;
    r = Math.max(0, Math.min(1, r));
    let v = min + r * (max - min);
    v = Math.round(v / step) * step;
    if (!controlled) setSelf(v);
    onChange && onChange(v);
  };
  const down = e => {
    setFromEvent(e);
    const move = ev => setFromEvent(ev);
    const up = () => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    onMouseDown: down,
    style: {
      position: 'relative',
      width,
      height: 24,
      display: 'flex',
      alignItems: 'center',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      height: 2,
      borderRadius: 2,
      background: 'var(--geist-accents-2)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      width: `${pct}%`,
      height: 2,
      borderRadius: 2,
      background: 'var(--geist-foreground)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: `${pct}%`,
      transform: 'translateX(-50%)',
      width: 14,
      height: 14,
      borderRadius: '50%',
      background: '#fff',
      border: '2px solid var(--geist-foreground)',
      boxShadow: 'var(--geist-shadow-small)'
    }
  }));
}
Object.assign(__ds_scope, { Slider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Slider.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
function Textarea({
  width = '208px',
  disabled = false,
  value,
  defaultValue,
  placeholder,
  onChange,
  rows = 4,
  style,
  ...rest
}) {
  const [focus, setFocus] = useState(false);
  const [val, setVal] = useState(defaultValue || '');
  const controlled = value !== undefined;
  const cur = controlled ? value : val;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      width,
      border: `1px solid ${disabled ? 'var(--geist-accents-2)' : focus ? '#000' : 'var(--geist-border)'}`,
      background: disabled ? 'var(--geist-accents-1)' : '#fff',
      borderRadius: 'var(--geist-radius)',
      transition: 'border .2s ease',
      ...style
    }
  }, /*#__PURE__*/React.createElement("textarea", _extends({
    rows: rows,
    value: cur,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    onChange: e => {
      if (!controlled) setVal(e.target.value);
      onChange && onChange(e);
    },
    style: {
      width: '100%',
      resize: 'none',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      padding: '8px 10px',
      fontSize: 14,
      lineHeight: 1.5,
      color: 'var(--geist-foreground)',
      fontFamily: 'var(--geist-font-sans)',
      cursor: disabled ? 'not-allowed' : 'text'
    }
  }, rest)));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/forms/Toggle.jsx
try { (() => {
const {
  useState
} = React;
function Toggle({
  checked,
  initialChecked = false,
  disabled = false,
  type = 'success',
  onChange,
  style
}) {
  const [self, setSelf] = useState(initialChecked);
  const controlled = checked !== undefined;
  const on = controlled ? checked : self;
  const bg = {
    success: 'var(--geist-success)',
    warning: 'var(--geist-warning)',
    error: 'var(--geist-error)',
    secondary: 'var(--geist-foreground)',
    default: 'var(--geist-foreground)'
  }[type] || 'var(--geist-success)';
  const H = 14,
    W = 28;
  const click = () => {
    if (disabled) return;
    if (!controlled) setSelf(!on);
    onChange && onChange({
      target: {
        checked: !on
      }
    });
  };
  return /*#__PURE__*/React.createElement("label", {
    onClick: click,
    style: {
      display: 'inline-block',
      width: W,
      height: H,
      position: 'relative',
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      width: '100%',
      height: '100%',
      borderRadius: H,
      background: disabled ? 'var(--geist-accents-1)' : on ? bg : 'var(--geist-accents-2)',
      border: disabled ? '1px solid var(--geist-accents-2)' : '1px solid transparent',
      transition: 'background .2s ease .12s, border .2s ease',
      boxSizing: 'border-box'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '50%',
      left: on ? `calc(100% - ${H - 2}px - 1px)` : 1,
      transform: 'translateY(-50%)',
      width: H - 2,
      height: H - 2,
      borderRadius: '50%',
      background: disabled ? 'var(--geist-accents-2)' : '#fff',
      boxShadow: on ? 'none' : 'rgba(0,0,0,.2) 0 1px 2px 0, rgba(0,0,0,.1) 0 1px 3px 0',
      transition: 'left 280ms cubic-bezier(0,0,0.2,1)'
    }
  }));
}
Object.assign(__ds_scope, { Toggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Toggle.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumbs.jsx
try { (() => {
function Breadcrumbs({
  items = [],
  separator = '/',
  style
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      fontFamily: 'var(--geist-font-sans)',
      fontSize: 14,
      color: 'var(--geist-accents-5)',
      ...style
    }
  }, items.map((it, i) => {
    const last = i === items.length - 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        color: last ? 'var(--geist-accents-4)' : 'var(--geist-accents-5)',
        cursor: it.href && !last ? 'pointer' : 'default'
      }
    }, it.icon, it.label), !last && /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--geist-accents-2)'
      }
    }, separator));
  }));
}
Object.assign(__ds_scope, { Breadcrumbs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumbs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Link.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
function Link({
  href = '#',
  color = false,
  underline = false,
  icon = false,
  block = false,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const colored = color || block;
  const base = colored ? 'var(--geist-link)' : 'inherit';
  const hov = colored ? 'var(--geist-success-light)' : 'inherit';
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 3,
      lineHeight: 'inherit',
      color: hover ? hov : base,
      textDecoration: underline ? 'underline' : 'none',
      fontFamily: 'var(--geist-font-sans)',
      borderRadius: block ? 'var(--geist-radius)' : 0,
      padding: block ? '2px 4px' : 0,
      background: block && hover ? 'rgba(0,112,243,.1)' : 'transparent',
      transition: 'color .2s ease, background .2s ease',
      ...style
    }
  }, rest), children, icon && /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "15 3 21 3 21 9"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "10",
    y1: "14",
    x2: "21",
    y2: "3"
  })));
}
Object.assign(__ds_scope, { Link });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Link.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Pagination.jsx
try { (() => {
const {
  useState
} = React;
function Pagination({
  count = 5,
  page,
  initialPage = 1,
  onChange,
  style
}) {
  const [self, setSelf] = useState(initialPage);
  const controlled = page !== undefined;
  const cur = controlled ? page : self;
  const go = p => {
    if (p < 1 || p > count) return;
    if (!controlled) setSelf(p);
    onChange && onChange(p);
  };
  const cell = (content, opts = {}) => /*#__PURE__*/React.createElement("button", {
    onClick: opts.onClick,
    disabled: opts.disabled,
    style: {
      minWidth: 36,
      height: 36,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: `1px solid ${opts.active ? 'var(--geist-foreground)' : 'var(--geist-border)'}`,
      background: '#fff',
      color: opts.disabled ? 'var(--geist-accents-3)' : opts.active ? 'var(--geist-foreground)' : 'var(--geist-accents-5)',
      borderRadius: 'var(--geist-radius)',
      fontFamily: 'var(--geist-font-sans)',
      fontSize: 14,
      cursor: opts.disabled ? 'not-allowed' : 'pointer',
      fontWeight: opts.active ? 600 : 400,
      padding: 0
    }
  }, content);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      gap: 6,
      ...style
    }
  }, cell('‹', {
    onClick: () => go(cur - 1),
    disabled: cur === 1
  }), [...Array(count)].map((_, i) => cell(i + 1, {
    active: cur === i + 1,
    onClick: () => go(i + 1)
  })), cell('›', {
    onClick: () => go(cur + 1),
    disabled: cur === count
  }));
}
Object.assign(__ds_scope, { Pagination });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Pagination.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
const {
  useState
} = React;
function Tabs({
  tabs = [],
  value,
  initialValue,
  onChange,
  children,
  style
}) {
  const [self, setSelf] = useState(initialValue !== undefined ? initialValue : tabs[0] && tabs[0].value);
  const controlled = value !== undefined;
  const cur = controlled ? value : self;
  const pick = v => {
    if (!controlled) setSelf(v);
    onChange && onChange(v);
  };
  const active = tabs.find(t => t.value === cur);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--geist-font-sans)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      borderBottom: '1px solid var(--geist-border)',
      paddingLeft: 12
    }
  }, tabs.map(t => {
    const on = t.value === cur;
    return /*#__PURE__*/React.createElement("div", {
      key: t.value,
      onClick: () => pick(t.value),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        padding: '10px 12px',
        fontSize: 14,
        cursor: 'pointer',
        marginBottom: -1,
        color: on ? 'var(--geist-foreground)' : 'var(--geist-accents-5)',
        borderBottom: `1px solid ${on ? 'var(--geist-foreground)' : 'transparent'}`,
        transition: 'color .15s ease'
      },
      onMouseEnter: e => {
        if (!on) e.currentTarget.style.color = 'var(--geist-foreground)';
      },
      onMouseLeave: e => {
        if (!on) e.currentTarget.style.color = 'var(--geist-accents-5)';
      }
    }, t.icon, t.label);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 10,
      fontSize: 14,
      color: 'var(--geist-foreground)'
    }
  }, active && active.content ? active.content : children));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Collapse.jsx
try { (() => {
const {
  useState
} = React;
function Collapse({
  title,
  subtitle,
  initialVisible = false,
  shadow = false,
  children,
  style
}) {
  const [open, setOpen] = useState(initialVisible);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--geist-border)',
      borderBottom: '1px solid var(--geist-border)',
      fontFamily: 'var(--geist-font-sans)',
      boxShadow: shadow ? 'var(--geist-shadow-small)' : 'none',
      borderRadius: shadow ? 'var(--geist-radius)' : 0,
      border: shadow ? '1px solid var(--geist-border)' : undefined,
      padding: shadow ? '0 16px' : 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => setOpen(!open),
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      cursor: 'pointer',
      padding: '16px 0'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: 'var(--geist-foreground)'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--geist-accents-5)',
      marginTop: 2
    }
  }, subtitle)), /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--geist-accents-5)",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      transform: open ? 'rotate(180deg)' : 'none',
      transition: 'transform .2s ease'
    }
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  }))), open && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 0 16px',
      fontSize: 14,
      lineHeight: 1.6,
      color: 'var(--geist-accents-6)'
    }
  }, children));
}
Object.assign(__ds_scope, { Collapse });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Collapse.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Modal.jsx
try { (() => {
function Modal({
  visible = false,
  title,
  subtitle,
  onClose,
  actions,
  children,
  width = 420,
  style
}) {
  if (!visible) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 1000,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'rgba(0,0,0,.25)',
      fontFamily: 'var(--geist-font-sans)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width,
      maxWidth: '90vw',
      background: '#fff',
      borderRadius: 'var(--geist-radius)',
      boxShadow: 'var(--geist-shadow-large)',
      overflow: 'hidden',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 16px',
      textAlign: 'center'
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 600,
      color: 'var(--geist-foreground)'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--geist-accents-5)',
      marginTop: 4
    }
  }, subtitle)), children != null && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 20px 20px',
      fontSize: 14,
      lineHeight: 1.6,
      color: 'var(--geist-foreground)',
      textAlign: 'center'
    }
  }, children), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      borderTop: '1px solid var(--geist-border)'
    }
  }, actions.map((a, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: a.onClick,
    style: {
      flex: 1,
      height: 48,
      border: 'none',
      background: '#fff',
      cursor: 'pointer',
      fontFamily: 'var(--geist-font-sans)',
      fontSize: 14,
      color: a.type === 'secondary' ? 'var(--geist-foreground)' : 'var(--geist-accents-5)',
      fontWeight: a.type === 'secondary' ? 500 : 400,
      borderLeft: i > 0 ? '1px solid var(--geist-border)' : 'none'
    },
    onMouseEnter: e => e.currentTarget.style.background = 'var(--geist-accents-1)',
    onMouseLeave: e => e.currentTarget.style.background = '#fff'
  }, a.label)))));
}
Object.assign(__ds_scope, { Modal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Modal.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Tooltip.jsx
try { (() => {
const {
  useState
} = React;
function Tooltip({
  text,
  placement = 'top',
  children,
  style
}) {
  const [show, setShow] = useState(false);
  const pos = {
    top: {
      bottom: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginBottom: 8
    },
    bottom: {
      top: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginTop: 8
    },
    left: {
      right: '100%',
      top: '50%',
      transform: 'translateY(-50%)',
      marginRight: 8
    },
    right: {
      left: '100%',
      top: '50%',
      transform: 'translateY(-50%)',
      marginLeft: 8
    }
  }[placement];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      ...pos,
      zIndex: 100,
      whiteSpace: 'nowrap',
      background: '#fff',
      color: 'var(--geist-foreground)',
      fontFamily: 'var(--geist-font-sans)',
      fontSize: 14,
      padding: '7px 12px',
      borderRadius: 'var(--geist-radius)',
      boxShadow: 'var(--geist-shadow-medium)',
      border: '1px solid var(--geist-border)'
    }
  }, text));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Tooltip.jsx", error: String((e && e.message) || e) }); }

// ui_kits/geist-docs/Docs.jsx
try { (() => {
// Geist docs — component documentation page
function Docs({
  active
}) {
  const NS = window.GeistUIDesignSystem_60c7d9;
  const {
    Button,
    Input,
    Card,
    Select,
    Checkbox,
    Toggle,
    Note,
    Loading,
    Spinner,
    Tag,
    Badge,
    Dot,
    Avatar,
    Snippet,
    Keyboard,
    Table
  } = NS;
  const [tab, setTab] = React.useState('default');
  const DOCS = {
    Button: {
      desc: 'Used to trigger an operation, with several types and states.',
      demos: [{
        title: 'Types',
        node: /*#__PURE__*/React.createElement("div", {
          style: S.row
        }, /*#__PURE__*/React.createElement(Button, {
          auto: true
        }, "Default"), /*#__PURE__*/React.createElement(Button, {
          auto: true,
          type: "secondary"
        }, "Secondary"), /*#__PURE__*/React.createElement(Button, {
          auto: true,
          type: "success"
        }, "Success"), /*#__PURE__*/React.createElement(Button, {
          auto: true,
          type: "error"
        }, "Error"))
      }, {
        title: 'Loading & disabled',
        node: /*#__PURE__*/React.createElement("div", {
          style: S.row
        }, /*#__PURE__*/React.createElement(Button, {
          auto: true,
          loading: true,
          type: "secondary"
        }, "Loading"), /*#__PURE__*/React.createElement(Button, {
          auto: true,
          disabled: true
        }, "Disabled"), /*#__PURE__*/React.createElement(Button, {
          auto: true,
          ghost: true,
          type: "success"
        }, "Ghost"))
      }],
      props: [['type', 'default | secondary | success | warning | error | abort', 'default'], ['ghost', 'boolean', 'false'], ['loading', 'boolean', 'false'], ['shadow', 'boolean', 'false'], ['disabled', 'boolean', 'false']]
    },
    Input: {
      desc: 'Retrieve text input from a user.',
      demos: [{
        title: 'Basic & label',
        node: /*#__PURE__*/React.createElement("div", {
          style: S.row
        }, /*#__PURE__*/React.createElement(Input, {
          placeholder: "Enter here"
        }), /*#__PURE__*/React.createElement(Input, {
          label: "https://",
          placeholder: "geist.dev"
        }))
      }, {
        title: 'Clearable & error',
        node: /*#__PURE__*/React.createElement("div", {
          style: S.row
        }, /*#__PURE__*/React.createElement(Input, {
          clearable: true,
          defaultValue: "Value"
        }), /*#__PURE__*/React.createElement(Input, {
          type: "error",
          placeholder: "Invalid"
        }))
      }],
      props: [['type', 'default | success | warning | error', 'default'], ['label', 'string', '-'], ['clearable', 'boolean', 'false'], ['disabled', 'boolean', 'false']]
    },
    Card: {
      desc: 'A flexible, quiet container for grouping related content.',
      demos: [{
        title: 'Default & shadow',
        node: /*#__PURE__*/React.createElement("div", {
          style: S.row
        }, /*#__PURE__*/React.createElement(Card, {
          width: "220px"
        }, "A basic card with a light border."), /*#__PURE__*/React.createElement(Card, {
          width: "220px",
          shadow: true
        }, "A card with a permanent shadow."))
      }],
      props: [['type', 'default | success | warning | error', 'default'], ['shadow', 'boolean', 'false'], ['hoverable', 'boolean', 'false']]
    },
    Note: {
      desc: 'Display a callout for a piece of important context.',
      demos: [{
        title: 'Types',
        node: /*#__PURE__*/React.createElement("div", {
          style: {
            display: 'flex',
            flexDirection: 'column',
            gap: 10
          }
        }, /*#__PURE__*/React.createElement(Note, null, "Neutral context."), /*#__PURE__*/React.createElement(Note, {
          type: "success"
        }, "All systems operational."), /*#__PURE__*/React.createElement(Note, {
          type: "error",
          label: "error"
        }, "Something went wrong."))
      }],
      props: [['type', 'default | secondary | success | warning | error', 'default'], ['label', 'string | false', 'note'], ['filled', 'boolean', 'false']]
    }
  };
  const generic = {
    desc: 'A Geist UI primitive. Interactive examples below.',
    demos: [{
      title: 'Preview',
      node: /*#__PURE__*/React.createElement("div", {
        style: S.row
      }, /*#__PURE__*/React.createElement(Tag, {
        type: "success"
      }, "tag"), /*#__PURE__*/React.createElement(Badge, {
        type: "error"
      }, "5"), /*#__PURE__*/React.createElement(Dot, {
        type: "warning"
      }, "Status"), /*#__PURE__*/React.createElement(Avatar, {
        text: "GU"
      }), /*#__PURE__*/React.createElement(Keyboard, {
        command: true
      }, "K"), /*#__PURE__*/React.createElement(Loading, null), /*#__PURE__*/React.createElement(Spinner, null), /*#__PURE__*/React.createElement(Toggle, {
        initialChecked: true
      }), /*#__PURE__*/React.createElement(Checkbox, {
        initialChecked: true
      }, "Check"), /*#__PURE__*/React.createElement(Select, {
        placeholder: "Select",
        options: [{
          label: 'One',
          value: '1'
        }, {
          label: 'Two',
          value: '2'
        }]
      }))
    }],
    props: [['type', 'string', 'default'], ['disabled', 'boolean', 'false']]
  };
  const doc = DOCS[active] || generic;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: '40px 56px 80px',
      maxWidth: 820
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--geist-accents-4)',
      marginBottom: 8
    }
  }, "Components"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 36,
      fontWeight: 700,
      letterSpacing: '-.02em',
      margin: '0 0 10px'
    }
  }, active), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 16,
      color: 'var(--geist-accents-5)',
      lineHeight: 1.6,
      margin: '0 0 36px'
    }
  }, doc.desc), doc.demos.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      margin: '0 0 14px',
      color: 'var(--geist-accents-7)'
    }
  }, d.title), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--geist-border)',
      borderRadius: 'var(--geist-radius)',
      padding: '28px 24px',
      display: 'flex',
      alignItems: 'center',
      flexWrap: 'wrap',
      gap: 14,
      minHeight: 40
    }
  }, d.node))), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      margin: '40px 0 14px',
      color: 'var(--geist-accents-7)'
    }
  }, "Props"), /*#__PURE__*/React.createElement(Table, {
    columns: [{
      prop: 'name',
      label: 'Prop'
    }, {
      prop: 'type',
      label: 'Type',
      render: v => /*#__PURE__*/React.createElement("code", {
        style: {
          fontFamily: 'var(--geist-font-mono)',
          fontSize: 12,
          color: 'var(--geist-code)'
        }
      }, v)
    }, {
      prop: 'def',
      label: 'Default'
    }],
    data: doc.props.map(p => ({
      name: p[0],
      type: p[1],
      def: p[2]
    }))
  }));
}
const S = {
  row: {
    display: 'flex',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 12
  }
};
window.Docs = Docs;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/geist-docs/Docs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/geist-docs/Home.jsx
try { (() => {
// Geist docs — landing / guide home
function Home({
  onNav
}) {
  const NS = window.GeistUIDesignSystem_60c7d9;
  const {
    Button,
    Snippet
  } = NS;
  const features = [{
    icon: 'zap',
    title: 'Lightweight',
    body: 'Minimal footprint. Ship only what you use with full tree-shaking support.'
  }, {
    icon: 'sliders',
    title: 'Customizable',
    body: 'Adjust the theme, or build your own on top of the shared design tokens.'
  }, {
    icon: 'moon',
    title: 'Dark mode',
    body: 'A first-class dark theme ships out of the box — flip a single provider prop.'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1000,
      margin: '0 auto',
      padding: '80px 24px 64px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo.png",
    alt: "Geist",
    style: {
      width: 64,
      height: 64,
      borderRadius: 12,
      marginBottom: 28
    }
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 56,
      fontWeight: 700,
      letterSpacing: '-.03em',
      lineHeight: 1.05,
      margin: '0 0 16px'
    }
  }, "Modern and minimalist", /*#__PURE__*/React.createElement("br", null), "React UI library."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 19,
      color: 'var(--geist-accents-5)',
      maxWidth: 560,
      margin: '0 auto 32px',
      lineHeight: 1.5
    }
  }, "An open-source design system for building consistent, high-quality web applications \u2014 the way Vercel does."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'center',
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement(Button, {
    auto: true,
    type: "secondary",
    shadow: true,
    onClick: () => onNav('docs')
  }, "Get Started"), /*#__PURE__*/React.createElement(Button, {
    auto: true,
    onClick: () => onNav('docs')
  }, "Components")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center',
      marginBottom: 72
    }
  }, /*#__PURE__*/React.createElement(Snippet, {
    text: "yarn add @geist-ui/core",
    width: "300px"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 20,
      textAlign: 'left'
    }
  }, features.map(f => /*#__PURE__*/React.createElement("div", {
    key: f.title,
    style: {
      border: '1px solid var(--geist-border)',
      borderRadius: 'var(--geist-radius)',
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-feather": f.icon,
    style: {
      width: 24,
      height: 24,
      strokeWidth: 1.5,
      color: 'var(--geist-foreground)'
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 17,
      fontWeight: 600,
      margin: '16px 0 6px'
    }
  }, f.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'var(--geist-accents-5)',
      lineHeight: 1.6,
      margin: 0
    }
  }, f.body)))));
}
window.Home = Home;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/geist-docs/Home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/geist-docs/Sidebar.jsx
try { (() => {
// Geist docs — left component sidebar
const SIDEBAR = [{
  group: 'Getting Started',
  items: ['Introduction', 'Installation', 'Themes']
}, {
  group: 'General',
  items: ['Button', 'Text', 'Link', 'Card', 'Grid']
}, {
  group: 'Data Entry',
  items: ['Input', 'Select', 'Checkbox', 'Radio', 'Toggle', 'Slider']
}, {
  group: 'Feedback',
  items: ['Note', 'Loading', 'Spinner', 'Progress', 'Modal']
}, {
  group: 'Others',
  items: ['Tag', 'Badge', 'Dot', 'Avatar', 'Snippet', 'Keyboard']
}];
function Sidebar({
  active,
  onSelect
}) {
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 240,
      flexShrink: 0,
      borderRight: '1px solid var(--geist-border)',
      padding: '24px 0 40px',
      height: 'calc(100vh - 60px)',
      overflowY: 'auto',
      position: 'sticky',
      top: 60
    }
  }, SIDEBAR.map(sec => /*#__PURE__*/React.createElement("div", {
    key: sec.group,
    style: {
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      textTransform: 'uppercase',
      letterSpacing: '.05em',
      color: 'var(--geist-accents-4)',
      fontWeight: 600,
      padding: '0 24px 8px'
    }
  }, sec.group), sec.items.map(it => {
    const on = it === active;
    return /*#__PURE__*/React.createElement("div", {
      key: it,
      onClick: () => onSelect(it),
      style: {
        fontSize: 14,
        padding: '6px 24px',
        cursor: 'pointer',
        color: on ? 'var(--geist-foreground)' : 'var(--geist-accents-5)',
        fontWeight: on ? 600 : 400,
        borderLeft: `2px solid ${on ? 'var(--geist-foreground)' : 'transparent'}`,
        background: on ? 'var(--geist-accents-1)' : 'transparent',
        transition: 'color .12s'
      },
      onMouseEnter: e => e.currentTarget.style.color = 'var(--geist-foreground)',
      onMouseLeave: e => {
        if (!on) e.currentTarget.style.color = 'var(--geist-accents-5)';
      }
    }, it);
  }))));
}
window.Sidebar = Sidebar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/geist-docs/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/geist-docs/TopNav.jsx
try { (() => {
// Geist docs — top navigation bar
function TopNav({
  onNav,
  route
}) {
  const link = (label, key) => /*#__PURE__*/React.createElement("span", {
    onClick: () => onNav(key),
    style: {
      fontSize: 14,
      cursor: 'pointer',
      padding: '0 2px',
      height: 60,
      display: 'inline-flex',
      alignItems: 'center',
      color: route === key ? 'var(--geist-foreground)' : 'var(--geist-accents-5)',
      borderBottom: `2px solid ${route === key ? 'var(--geist-foreground)' : 'transparent'}`,
      transition: 'color .15s ease'
    },
    onMouseEnter: e => e.currentTarget.style.color = 'var(--geist-foreground)',
    onMouseLeave: e => {
      if (route !== key) e.currentTarget.style.color = 'var(--geist-accents-5)';
    }
  }, label);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: 60,
      borderBottom: '1px solid var(--geist-border)',
      display: 'flex',
      alignItems: 'center',
      padding: '0 24px',
      gap: 26,
      position: 'sticky',
      top: 0,
      background: 'rgba(255,255,255,.9)',
      backdropFilter: 'saturate(180%) blur(6px)',
      zIndex: 50
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: () => onNav('home'),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo.png",
    alt: "Geist",
    style: {
      width: 26,
      height: 26,
      borderRadius: 6
    }
  }), /*#__PURE__*/React.createElement("b", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      letterSpacing: '-.01em'
    }
  }, "Geist UI")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 22,
      marginLeft: 8,
      alignSelf: 'stretch'
    }
  }, link('Guide', 'home'), link('Components', 'docs'), link('Hooks', 'docs'), link('Customization', 'home')), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      color: 'var(--geist-accents-5)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-feather": "search",
    style: {
      width: 18,
      height: 18
    }
  }), /*#__PURE__*/React.createElement("i", {
    "data-feather": "github",
    style: {
      width: 18,
      height: 18,
      cursor: 'pointer'
    }
  }), /*#__PURE__*/React.createElement("i", {
    "data-feather": "moon",
    style: {
      width: 18,
      height: 18,
      cursor: 'pointer'
    }
  })));
}
window.TopNav = TopNav;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/geist-docs/TopNav.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Code = __ds_scope.Code;

__ds_ns.Dot = __ds_scope.Dot;

__ds_ns.Keyboard = __ds_scope.Keyboard;

__ds_ns.Snippet = __ds_scope.Snippet;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Text = __ds_scope.Text;

__ds_ns.User = __ds_scope.User;

__ds_ns.Loading = __ds_scope.Loading;

__ds_ns.Note = __ds_scope.Note;

__ds_ns.Progress = __ds_scope.Progress;

__ds_ns.Spinner = __ds_scope.Spinner;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Slider = __ds_scope.Slider;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Toggle = __ds_scope.Toggle;

__ds_ns.Breadcrumbs = __ds_scope.Breadcrumbs;

__ds_ns.Link = __ds_scope.Link;

__ds_ns.Pagination = __ds_scope.Pagination;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Collapse = __ds_scope.Collapse;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.Tooltip = __ds_scope.Tooltip;

})();
